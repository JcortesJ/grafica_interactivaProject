//Función para cambiar el párrafo posterior al mapa interactivo para contener información sobre el primer punto.
function Punto1() {
	document.getElementById("Info").innerHTML = '<img class="imgM" src="images/foto08.jpg" alt="punto uno"><br><span>Entrada calle 26</span><br><br>Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto, texto, texto y mucho mas texto. Texto, texto y mucho mas texto. Texto, texto y texto, texto, texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto.<br> Texto, texto y mas texto. Texto, texto y mas texto.';
	document.getElementById("Info").scrollIntoView();
}

//Función para cambiar el párrafo posterior al mapa interactivo para contener información sobre el segundo punto.
function Punto2() {
	document.getElementById("Info").innerHTML = '<img class="imgM" src="images/foto05.jpg" alt="punto dos"><br><span>Entrada carrera 45</span><br><br>Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto, texto, texto y mucho mas texto. Texto, texto y mucho mas texto. Texto, texto y texto, texto, texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. ';
	document.getElementById("Info").scrollIntoView();
}

//Función para cambiar el párrafo posterior al mapa interactivo para contener información sobre el tercer punto.
function Punto3() {
	document.getElementById("Info").innerHTML = '<img class="imgM" src="images/foto30.jpg" alt="punto tres"><br><span>Entrada carrera 30</span><br><br>Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto, texto, texto y mucho mas texto. Texto, texto y mucho mas texto. Texto, texto y texto, texto, texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto.';
	document.getElementById("Info").scrollIntoView();
}

//Función para cambiar el párrafo posterior al mapa interactivo para contener información sobre el cuarto punto.
function Punto4() {
	document.getElementById("Info").innerHTML = '<img class="imgM" src="images/foto01.jpg" alt="punto cuatro"><br><span>Plaza Che</span><br><br>Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto, texto, texto y mucho mas texto. Texto, texto y mucho mas texto. Texto, texto y texto, texto, texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. <br>Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto.<br>Texto, texto y mas texto. Texto, texto y mucho mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto. Texto, texto y mas texto.';
	document.getElementById("Info").scrollIntoView();
}